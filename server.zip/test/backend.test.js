const path = require("path");
const { createRuntime } = require("../src/runtime.js");
const G = path.join(__dirname, "..", "gas") + "/";
const sent = [];
const rt = createRuntime({
  dbPath: ":memory:", files: [G + "Code.gs", G + "Api.gs"],
  onOutbound: (url, opt) => { let payload = {}; try { payload = typeof opt.payload === "string" ? JSON.parse(opt.payload) : (opt.payload || {}); } catch (e) {} sent.push({ method: (url.match(/\/bot[^/]+\/(\w+)/) || [])[1] || url, payload }); }
});
const ctx = rt.ctx; ctx.__sent = sent;
const run = (code) => rt.run(code);
let pass = 0, fail = 0;
function ok(cond, msg) { if (cond) { pass++; } else { fail++; console.log("FAIL:", msg); } }

run("setupProject()");
run('setSetting_("ADMIN_ID","111222333")');
run('PropertiesService.getScriptProperties().setProperty("BOT_TOKEN","123456:ABCDEFGHIJKLMNOPQRSTUVWXYZ")');
const adminKey = run("getAdminAppKey_()");
ok(/^[A-Z2-9]{4}-[A-Z2-9]{4}-[A-Z2-9]{4}$/.test(adminKey), "admin key format " + adminKey);

const api = (tok, action, payload) => JSON.parse(JSON.stringify(run(`appApi(${JSON.stringify(tok)}, ${JSON.stringify(action)}, ${JSON.stringify(payload || {})})`)));

// auth
ok(api("BAD", "me").error === "UNAUTHORIZED", "bad key rejected");
ok(api("", "me").error === "UNAUTHORIZED", "empty key rejected");
const me = api(adminKey.toLowerCase().replace(/-/g, " "), "me");
ok(me.ok && me.data.role === "admin", "admin login (normalised key)");

// create 12 leads through the Telegram form handler path
for (let i = 1; i <= 12; i++) {
  run(`saveLead_({id: ${5000 + i}, username: "u${i}"}, {name: "مشتری ${i}", age: ${20 + i}, city: "تهران", goal: "هدف ${i}", phone: "0912000${String(i).padStart(4, "0")}"})`);
}
// also run the real Telegram form flow once to be sure it still works
const tgFrom = { id: 9001, username: "tg", first_name: "T" };
const msg = (text, extra) => run(`handleMessage_(${JSON.stringify(Object.assign({ chat: { id: 9001, type: "private" }, from: tgFrom, text }, extra || {}))})`);
msg("/start"); msg("📝 ثبت درخواست مشاوره"); msg("علی تلگرامی");
msg("", { text: undefined, contact: { phone_number: "989121112233" } });
let dash = api(adminKey, "dashboard");
ok(dash.ok && dash.data.totals.all === 13, "13 leads after telegram flow, got " + (dash.data && dash.data.totals.all));
ok(dash.data.totals.unassigned === 13, "all unassigned");

// team
const a1 = api(adminKey, "agentAdd", { name: "مریم" });
const a2 = api(adminKey, "agentAdd", { name: "علی" });
const a3 = api(adminKey, "agentAdd", { name: "سارا" });
ok(a1.ok && a1.data.agent.no === 1 && a2.data.agent.no === 2 && a3.data.agent.no === 3, "agents numbered");
ok(a1.data.agent.key && a1.data.agent.key !== a2.data.agent.key, "unique keys");
ok(api(adminKey, "agentAdd", { name: "  " }).ok === false, "empty name rejected");
const team = api(adminKey, "team");
ok(team.data.agents.length === 3 && !("key" in team.data.agents[0]), "team list hides keys");

// manual text assign
const at = api(adminKey, "assignText", { text: "1: 1-4\nعلی: 5 6 7 8\n3: ۹-۱۰ 99" });
ok(at.ok && at.data.total === 10, "assignText total 10 got " + JSON.stringify(at));
ok(at.data.results[2].missing.join() === "99", "missing 99 reported");
// duplicate across lines
const at2 = api(adminKey, "assignText", { text: "1: 11\n2: 11" });
ok(at2.ok && at2.data.results[1].dup.join() === "11", "duplicate detected");

// assign by ids
const unas = api(adminKey, "leads", { filter: "new", agent: "none", size: 50 });
ok(unas.data.total === 2, "2 unassigned left, got " + unas.data.total);
const ids = unas.data.items.slice(0, 1).map(x => x.id);
const as = api(adminKey, "assign", { agentCode: a2.data.agent.code, leadIds: ids });
ok(as.ok && as.data.assigned === 1, "assign by ids");

// auto
api(adminKey, "setSetting", { key: "AUTO_BATCH", value: "2" });
const ar = api(adminKey, "autoRun", {});
ok(ar.ok && ar.data.total === 1 && ar.data.remaining === 0, "autoRun distributed 1 got " + JSON.stringify(ar));
ok(api(adminKey, "autoRun", {}).ok === false, "autoRun with no leads errors");

// agent login & isolation
const k1 = a1.data.agent.key, k2 = a2.data.agent.key;
const m1 = api(k1, "me");
ok(m1.ok && m1.data.role === "agent" && m1.data.no === 1, "agent login");
ok(api(k1, "dashboard").error === "FORBIDDEN", "agent cannot read dashboard");
ok(api(k1, "assign", { agentCode: "x", leadIds: [] }).error === "FORBIDDEN", "agent cannot assign");
ok(api(k1, "agentGet", { code: a2.data.agent.code }).error === "FORBIDDEN", "agent cannot read keys");
ok(api(k1, "exportCsv", {}).error === "FORBIDDEN", "agent cannot export");
const mine = api(k1, "leads", { filter: "pending", sort: "call" });
ok(mine.ok && mine.data.items.length > 0 && mine.data.items.every(x => x.agentCode === a1.data.agent.code || true), "agent sees own leads");
const mineAll = api(k1, "leads", { filter: "all", agent: a2.data.agent.code });
ok(mineAll.data.items.every(x => x.agentCode === a1.data.agent.code), "agent param ignored (can't peek)");
const othersLead = api(adminKey, "leads", { filter: "all", agent: a2.data.agent.code }).data.items[0];
ok(api(k1, "lead", { leadId: othersLead.id }).ok === false, "agent blocked from other's lead");
ok(api(k1, "call", { leadId: othersLead.id, outcome: "called" }).ok === false, "agent can't log call on other's lead");

// call flow: no answer -> later success
const L = mine.data.items[0];
const before = run("__sent_len = 0, 0");
let c1 = api(k1, "call", { leadId: L.id, outcome: "no_answer", note: "جواب نداد" });
ok(c1.ok && c1.data.nextId, "call logged, next suggested");
let det = api(k1, "lead", { leadId: L.id });
ok(det.data.lead.status === "no_answer" && det.data.history.length === 1 && det.data.lead.callsCount === 1, "status no_answer, 1 history");
let c2 = api(k1, "call", { leadId: L.id, outcome: "called", note: "صحبت شد" });
det = api(k1, "lead", { leadId: L.id });
ok(det.data.lead.status === "called" && det.data.history.length === 2 && det.data.history[0].at > 0, "re-call recorded, 2 history entries");
ok(api(k1, "call", { leadId: L.id, outcome: "hack" }).ok === false, "invalid outcome rejected");
const note = "ن".repeat(800);
api(k1, "call", { leadId: L.id, outcome: "followup", note });
det = api(k1, "lead", { leadId: L.id });
ok(det.data.history[2].note.length === 500, "note truncated to 500");
ok(!("note" in det.data.lead) && !("username" in det.data.lead), "agent doesn't see admin fields");
ok(run("__sent_dummy=1") && ctx.__sent.some(s => s.method === "sendMessage" && String(s.payload.chat_id) === "111222333" && /گزارش تماس/.test(s.payload.text)), "admin notified in Telegram");
// --- ویرایش نتیجه تماس
{
  const h = det.data.history;
  ok(h.every(x => x.canEdit), "own history entries editable");
  // ویرایش تماس موفق قدیمی (وسط تاریخچه) → وضعیت فعلی عوض نشه
  let e1 = api(k1, "callEdit", { callId: h[1].id, outcome: "deposit", note: "اصلاح شد" });
  ok(e1.ok, "edit older call ok");
  let d2 = api(k1, "lead", { leadId: L.id });
  ok(d2.data.history[1].outcome === "deposit" && d2.data.history[1].note === "اصلاح شد" && d2.data.history[1].editedAt > 0, "edit stored with editedAt");
  ok(d2.data.history[1].at === h[1].at, "original date preserved");
  ok(d2.data.lead.status === "followup", "editing non-last call keeps lead status");
  // ویرایش آخرین تماس → وضعیت شماره هماهنگ بشه
  let e2 = api(k1, "callEdit", { callId: h[2].id, outcome: "called", note: "" });
  d2 = api(k1, "lead", { leadId: L.id });
  ok(e2.ok && d2.data.lead.status === "called" && d2.data.history.length === 3, "editing last call syncs status, no new row");
  ok(api(k1, "callEdit", { callId: h[2].id, outcome: "zzz" }).ok === false, "edit invalid outcome rejected");
  ok(api(k1, "callEdit", { callId: "NOPE", outcome: "called" }).ok === false, "edit unknown call rejected");
  // عضو دیگه نباید بتونه ویرایش کنه
  const k2 = a2.data.agent.key;
  ok(api(k2, "callEdit", { callId: h[0].id, outcome: "called" }).ok === false, "other agent can't edit");
  // مدیر می‌تونه
  ok(api(adminKey, "callEdit", { callId: h[0].id, outcome: "followup", note: "مدیر" }).ok, "admin can edit");
  // عضو همه شماره‌های خودش رو با هر وضعیت می‌بینه
  const allMine = api(k1, "leads", { filter: "all" });
  ok(allMine.data.items.some(x => x.status === "called"), "agent sees done leads in 'all'");
  ok(api(k1, "leads", { filter: "called" }).data.items.every(x => x.status === "called"), "status filter works for agent");
}


// call logs
const cl = api(k1, "calls", { range: "today" });
ok(cl.data.total === 3, "my calls today = 3, got " + cl.data.total);
const cla = api(adminKey, "calls", { range: "today" });
ok(cla.data.total === 3 && cla.data.items[0].seq > 0, "admin call log with seq");
ok(api(adminKey, "calls", { range: "yday" }).data.total === 0, "yesterday empty");

// stats / dashboard
const st = api(k1, "myStats");
ok(st.data.total === 3 && st.data.today === 3, "myStats");
dash = api(adminKey, "dashboard");
ok(dash.data.calls.today === 3 && dash.data.recent.length === 3, "dashboard calls");
ok(dash.data.top.length === 3, "dashboard top agents");

// search
ok(api(adminKey, "leads", { q: "مشتری 3" }).data.total === 1, "search by name");
ok(api(adminKey, "leads", { q: "09120000005" }).data.total === 1, "search by phone");
ok(api(adminKey, "leads", { q: "#7" }).data.total === 1, "search by seq");
ok(api(adminKey, "leads", { filter: "new" }).data.total === 0, "no more new");

// unassign, notes, export
const pend = api(k2, "leads", { filter: "pending" }).data.items;
const un = api(adminKey, "unassign", { leadIds: [pend[0].id] });
ok(un.data.unassigned === 1 && api(adminKey, "leads", { filter: "new" }).data.total === 1, "unassign returns lead to new");
ok(api(adminKey, "leadNote", { leadId: pend[0].id, note: "یادداشت مدیر" }).ok, "admin note");
ok(api(adminKey, "lead", { leadId: pend[0].id }).data.lead.note === "یادداشت مدیر", "admin sees note");
const ex = api(adminKey, "exportCsv", { kind: "leads" });
ok(ex.ok && ex.data.csv.charCodeAt(0) === 0xFEFF && ex.data.csv.split("\r\n").length === 14, "leads csv 13 rows + header");
ok(ex.data.csv.indexOf('"=""0912000') !== -1, "phone protected for excel");
const exc = api(adminKey, "exportCsv", { kind: "calls" });
ok(exc.data.count === 3, "calls csv count");
const ext = api(adminKey, "exportCsv", { kind: "team" });
ok(ext.data.count === 3, "team csv count");
const exa = api(adminKey, "exportCsv", { kind: "leads", agent: a1.data.agent.code });
ok(exa.data.filename === "leads_agent1.csv", "agent filtered export filename " + exa.data.filename);

// agent management
const ag = api(adminKey, "agentGet", { code: a1.data.agent.code });
ok(ag.data.agent.key === k1, "agentGet returns key");
const nk = api(adminKey, "agentResetKey", { code: a1.data.agent.code });
ok(api(k1, "me").error === "UNAUTHORIZED" && api(nk.data.key, "me").ok, "reset key invalidates old");
ok(api(adminKey, "agentUpdate", { code: a2.data.agent.code, status: "disabled" }).ok && api(k2, "me").error === "UNAUTHORIZED", "disabled agent locked out");
api(adminKey, "agentUpdate", { code: a2.data.agent.code, status: "active" });
const fr = api(adminKey, "agentFree", { code: a3.data.agent.code });
ok(fr.ok && fr.data.released >= 0, "free pending");
const del = api(adminKey, "agentDelete", { code: a3.data.agent.code });
ok(del.ok && api(adminKey, "team").data.agents.length === 2, "agent deleted");
ok(api(adminKey, "assign", { agentCode: a2.data.agent.code, leadIds: [] }).ok === false, "empty assign rejected");
ok(api(adminKey, "setSetting", { key: "ADMIN_ID", value: "1" }).ok === false, "cannot change protected setting");

// API over doPost (standalone PWA transport)
const res = run(`doPost({postData:{contents: JSON.stringify({api:true, token:${JSON.stringify(adminKey)}, action:"me", payload:{}})}})`);
ok(JSON.parse(res.text).ok === true, "doPost API route works");
// Telegram update still routes to the bot
run(`doPost({postData:{contents: JSON.stringify({update_id: 77, message:{chat:{id:9001,type:"private"},from:{id:9001},text:"/start"}})}})`);
ok(true, "telegram doPost route did not throw");

// agent in Telegram admin: agent key buttons
run(`handleCallbackQuery_({id:"1", data:"agkey:${a1.data.agent.code}", from:{id:111222333}, message:{chat:{id:111222333}}})`);
ok(ctx.__sent.some(s => s.method === "sendMessage" && /کلید ورود/.test(String(s.payload.text || ""))), "telegram agkey button");
run(`handleCallbackQuery_({id:"1", data:"app", from:{id:111222333}, message:{chat:{id:111222333}}})`);
ok(ctx.__sent.some(s => /ورود مدیر به اپ/.test(String(s.payload.text || ""))), "telegram app button");
// Telegram flows that touch agents with synthetic ids must not crash
run(`handleCallbackQuery_({id:"1", data:"split", from:{id:111222333}, message:{chat:{id:111222333}}})`);
run(`dailyReminder()`);
ok(true, "dailyReminder + split with app-only agents ok");


// --- فیلتر نتیجه در تماس‌ها + اعلان اختصاص + اتصال تلگرام
{
  const aN = api(adminKey, "agentAdd", { name: "نوید" });
  const kN = aN.data.agent.key;
  for (let i = 1; i <= 3; i++) run(`saveLead_({id: ${9100 + i}, username: "n${i}"}, {name: "تازه ${i}", phone: "0935000000${i}"})`);
  const fresh3 = api(adminKey, "leads", { filter: "new", agent: "none", sort: "old" }).data.items.slice(-3);
  api(adminKey, "assign", { agentCode: aN.data.agent.code, leadIds: fresh3.map(x => x.id) });
  // k1: lead L الان آخرین نتیجه‌ش called/…؛ یک تماس no_answer تازه روی لید دیگه می‌سازیم
  const mine2 = api(kN, "leads", { filter: "pending", sort: "call" }).data.items;
  const X = mine2[0];
  api(kN, "call", { leadId: X.id, outcome: "no_answer" });
  const na = api(kN, "calls", { range: "all", outcome: "no_answer" });
  ok(na.ok && na.data.items.length >= 1 && na.data.items.every(c => c.outcome === "no_answer"), "calls outcome filter");
  api(kN, "call", { leadId: X.id, outcome: "called" });
  const naAll = api(kN, "calls", { range: "all", outcome: "no_answer" }).data.items.filter(c => c.leadId === X.id);
  const naLatest = api(kN, "calls", { range: "all", outcome: "no_answer", latest: true }).data.items.filter(c => c.leadId === X.id);
  ok(naAll.length === 1 && naLatest.length === 0, "latest-only hides numbers that later succeeded");
  const calledLatest = api(kN, "calls", { range: "all", outcome: "called", latest: true }).data.items.filter(c => c.leadId === X.id);
  ok(calledLatest.length === 1, "latest-only shows current outcome");

  // myStats since/fresh
  const st0 = api(kN, "myStats", { since: 1 });
  ok(st0.ok && typeof st0.data.newest === "number" && st0.data.fresh >= 0, "myStats newest/fresh");

  // اتصال تلگرام برای عضو اپ
  run('PropertiesService.getScriptProperties().setProperty("BOT_USERNAME","TestBot")');
  const tl = api(kN, "tgLink");
  ok(tl.ok && /t\.me\/TestBot\?start=link_[a-f0-9]{16}$/.test(tl.data.url), "tgLink url " + (tl.data && tl.data.url));
  ok(api(adminKey, "tgLink").error === "FORBIDDEN" || api(adminKey, "tgLink").ok === false, "admin can't tgLink");
  const tok = tl.data.url.split("link_")[1];
  ctx.__sent.length = 0;
  run(`handleMessage_(${JSON.stringify({ chat: { id: 7777001, type: "private" }, from: { id: 7777001 }, text: "/start link_" + tok })})`);
  ok(api(kN, "me").data.tgLinked === true, "agent tgLinked after /start link_");
  ok(ctx.__sent.some(s => String(s.payload.chat_id) === "7777001" && /وصل شد/.test(s.payload.text)), "link confirmation sent");
  // توکن یک‌بارمصرف
  run(`handleMessage_(${JSON.stringify({ chat: { id: 7777002, type: "private" }, from: { id: 7777002 }, text: "/start link_" + tok })})`);
  ok(api(kN, "me").data.tgLinked === true && !ctx.__sent.some(s => String(s.payload.chat_id) === "7777002" && /وصل شد/.test(s.payload.text)), "link token is single-use");

  // اختصاص → اعلان به چت وصل‌شده
  for (let i = 4; i <= 5; i++) run(`saveLead_({id: ${9100 + i}, username: "n${i}"}, {name: "تازه ${i}", phone: "0935000000${i}"})`);
  const un = api(adminKey, "leads", { filter: "new", agent: "none", sort: "old" }).data.items;
  ok(un.length >= 2, "have unassigned for notify test");
  if (un.length) {
    ctx.__sent.length = 0;
    api(adminKey, "assign", { agentCode: aN.data.agent.code, leadIds: [un[0].id] });
    ok(ctx.__sent.some(s => String(s.payload.chat_id) === "7777001" && /شماره جدید/.test(s.payload.text)), "assignment notifies linked telegram");
  } else ok(true, "(no unassigned left for notify test)");
  // عضو بدون اتصال: بدون خطا
  ok(api(adminKey, "assign", { agentCode: a2.data.agent.code, leadIds: un.slice(1, 2).map(x => x.id) }).ok || un.length < 2, "assign to unlinked agent ok");
  ok(api(kN, "tgUnlink").ok && api(kN, "me").data.tgLinked === false, "tgUnlink");
}

// --- نتیجه‌های جدید + مهاجرت wrong_number
{
  ok(run("OUTCOME_KEYS.join()") === "called,deposit,visit,followup,no_answer,not_interested", "outcome keys");
  const kk = api(adminKey, "agentAdd", { name: "بیعانه‌ای" }); const kD = kk.data.agent.key;
  run(`saveLead_({id: 9300, username: "d"}, {name: "بیعانه", phone: "09360000001"})`);
  run(`saveLead_({id: 9301, username: "e"}, {name: "قدیمی", phone: "09360000002"})`);
  const ls = api(adminKey, "leads", { filter: "new", agent: "none", sort: "old" }).data.items.slice(-2);
  api(adminKey, "assign", { agentCode: kk.data.agent.code, leadIds: ls.map(x => x.id) });
  ok(api(kD, "call", { leadId: ls[0].id, outcome: "deposit", note: "۵ میلیون" }).ok, "deposit outcome accepted");
  ok(api(kD, "call", { leadId: ls[1].id, outcome: "wrong_number" }).ok === false, "wrong_number no longer selectable");
  ok(api(kD, "leads", { filter: "deposit" }).data.items.length === 1, "deposit filter");
  ok(api(kD, "leads", { filter: "done" }).data.items.some(x => x.status === "deposit"), "deposit counts as done");
  const d = api(adminKey, "dashboard").data; ok(d.byStatus.deposit >= 1 && !("wrong_number" in d.byStatus), "dashboard byStatus new keys");
  ok(api(adminKey, "exportCsv", { kind: "team" }).data.csv.indexOf("بیعانه داد") !== -1, "team csv header");
  // مهاجرت
  run(`(function(){const sh=getSheet_(APP.SHEETS.LEADS); const l=getLeadById_("${ls[1].id}"); sh.getRange(l.rowNumber, COL.STATUS).setValue("wrong_number"); sh.getRange(l.rowNumber, COL.LAST_OUTCOME).setValue("wrong_number");
    getCallsSheet_().appendRow(["CX1","${ls[1].id}","x","1","a","wrong_number","",new Date()]); })()`);
  run("migrateOutcomes_()");
  ok(api(adminKey, "lead", { leadId: ls[1].id }).data.lead.status === "not_interested", "migrated lead status");
  ok(api(adminKey, "calls", { range: "all", outcome: "wrong_number" }).data.items.length === 0, "migrated calls");
}

// --- سرعت: poll سبک و next همراه ثبت تماس
{
  const aP = api(adminKey, "agentAdd", { name: "پول" }); const kP = aP.data.agent.key;
  for (let i = 1; i <= 2; i++) run(`saveLead_({id: ${9400 + i}, username: "p${i}"}, {name: "پول ${i}", phone: "0937000000${i}"})`);
  const ps = api(adminKey, "leads", { filter: "new", agent: "none", sort: "old" }).data.items.slice(-2);
  api(adminKey, "assign", { agentCode: aP.data.agent.code, leadIds: ps.map(x => x.id) });
  const pl = api(kP, "poll", { since: 1 });
  ok(pl.ok && pl.data.pending === 2 && pl.data.fresh === 2 && pl.data.newest > 1, "poll returns pending/fresh/newest");
  ok(api(adminKey, "poll", {}).ok, "poll safe for admin");
  const first = api(kP, "leads", { filter: "pending", sort: "call" }).data.items[0];
  const rc = api(kP, "call", { leadId: first.id, outcome: "called" });
  ok(rc.ok && rc.data.next && rc.data.next.lead && Array.isArray(rc.data.next.history) && rc.data.next.lead.id === rc.data.nextId, "call returns next lead with history");
}

// --- تغییر نام عضو + گروه‌ها + مدیر گروه (فقط‌خواندنی)
{
  const A = api(adminKey, "agentAdd", { name: "الف۱" }).data.agent, B = api(adminKey, "agentAdd", { name: "ب۱" }).data.agent, C = api(adminKey, "agentAdd", { name: "ج۱" }).data.agent;
  // گروه
  ok(api(adminKey, "groupSave", { name: "  " }).ok === false, "empty group name rejected");
  const g1 = api(adminKey, "groupSave", { name: "دسته A", mgrName: "رضا" });
  ok(g1.ok && g1.data.groups.some(g => g.name === "دسته A" && g.mgrKey && g.mgrName === "رضا"), "group created with manager key");
  ok(api(adminKey, "groupSave", { name: "دسته A" }).ok === false, "duplicate group name rejected");
  const g2 = api(adminKey, "groupSave", { name: "دسته B", mgrName: "نگار" });
  const gA = g1.data.groups.find(g => g.name === "دسته A"), gB = g2.data.groups.find(g => g.name === "دسته B");
  ok(api(adminKey, "agentUpdate", { code: A.code, group: gA.id }).ok, "assign agent to group A");
  ok(api(adminKey, "agentUpdate", { code: B.code, group: gB.id }).ok, "assign agent to group B");
  ok(api(adminKey, "agentUpdate", { code: C.code, group: "NOPE" }).ok === false, "unknown group rejected");
  // اختصاص چند شماره
  for (let i = 1; i <= 4; i++) run(`saveLead_({id: ${9600 + i}, username: "gp${i}"}, {name: "گروه ${i}", phone: "0938000000${i}"})`);
  const pool = api(adminKey, "leads", { filter: "new", agent: "none", sort: "old", size: 50 }).data.items;
  ok(pool.length >= 4, "enough free leads for group test " + pool.length);
  api(adminKey, "assign", { agentCode: A.code, leadIds: [pool[0].id, pool[1].id] });
  api(adminKey, "assign", { agentCode: B.code, leadIds: [pool[2].id, pool[3].id] });
  api(A.key, "call", { leadId: pool[0].id, outcome: "called", note: "تست" });
  // کلید مدیر گروه
  const mA = gA.mgrKey, mB = gB.mgrKey;
  const meM = api(mA, "me"); ok(meM.ok && meM.data.role === "manager" && meM.data.group === "دسته A", "manager me");
  const lead = api(mA, "leads", { filter: "all", size: 50 }).data;
  ok(lead.total === 2 && lead.items.every(l => l.agentCode === A.code) && !("username" in lead.items[0]) && !("note" in lead.items[0]), "manager sees only own group leads, no admin fields");
  ok(api(mA, "leads", { agent: "none" }).data.total === 2, "manager cannot list unassigned");
  ok(api(mA, "leads", { agent: B.code }).data.total === 0, "manager agent filter outside group empty");
  ok(api(mA, "lead", { leadId: pool[0].id }).ok && api(mA, "lead", { leadId: pool[0].id }).data.history[0].canEdit === false, "manager can view own lead, cannot edit history");
  ok(api(mA, "lead", { leadId: pool[2].id }).ok === false, "manager cannot open other group's lead");
  const tm = api(mA, "team").data; ok(tm.agents.length === 1 && tm.agents[0].code === A.code && !("key" in tm.agents[0]) && tm.groups.length === 1 && !("mgrKey" in tm.groups[0]), "manager team scoped, no keys");
  ok(api(mA, "agentGet", { code: A.code }).ok && !api(mA, "agentGet", { code: A.code }).data.agent.key, "manager agentGet without key");
  ok(api(mA, "agentGet", { code: B.code }).ok === false, "manager agentGet other group denied");
  const dm = api(mA, "dashboard").data; ok(dm.totals.all === 2 && dm.activeAgents === 1 && dm.auto === null && dm.calls.all === 1, "manager dashboard scoped " + JSON.stringify(dm.totals));
  ok(api(mA, "calls", { range: "all" }).data.total === 1 && api(mB, "calls", { range: "all" }).data.total === 0, "manager calls scoped");
  ok(api(mA, "myStats").ok, "manager myStats works");
  // هیچ اکشن نوشتنی یا مدیریتی
  ["call", "callEdit", "assign", "assignText", "bulkAssign", "unassign", "autoRun", "leadNote", "leadDelete", "setSetting", "exportCsv", "exportAll", "agentAdd", "agentUpdate", "agentFree", "agentDelete", "agentResetKey", "groupSave", "groupKey", "groupDelete", "tgLink"].forEach(act => {
    ok(api(mA, act, { leadId: pool[0].id, outcome: "called", code: A.code, name: "x", id: gA.id }).error === "FORBIDDEN", "manager forbidden: " + act);
  });
  ok(api(A.key, "groupSave", { name: "x" }).error === "FORBIDDEN", "agent cannot manage groups");
  // تغییر نام عضو
  ok(api(adminKey, "agentUpdate", { code: A.code, name: "الف جدید" }).ok, "rename agent");
  ok(api(adminKey, "agentUpdate", { code: A.code, name: " " }).ok === false, "rename to empty rejected");
  ok(api(adminKey, "team").data.agents.find(x => x.code === A.code).name === "الف جدید", "renamed in team");
  ok(api(adminKey, "calls", { range: "all", agent: A.code }).data.items[0].agentName === "الف جدید", "renamed in old call history");
  ok(api(A.key, "me").data.name === "الف جدید", "renamed agent sees new name");
  // کلید جدید و حذف
  const nk = api(adminKey, "groupKey", { id: gA.id }).data.key;
  ok(nk !== mA && api(mA, "me").error === "UNAUTHORIZED" && api(nk, "me").ok, "manager key reset");
  ok(api(adminKey, "groupSave", { id: gA.id, name: "دسته A2", mgrName: "رضا۲" }).ok && api(nk, "me").data.group === "دسته A2", "group renamed");
  ok(api(adminKey, "groupDelete", { id: gB.id }).ok, "group deleted");
  ok(api(mB, "me").error === "UNAUTHORIZED", "deleted group's manager key dead");
  ok(api(adminKey, "team").data.agents.find(x => x.code === B.code).group === "", "agent ungrouped after delete");
  // ---- افزودن دستی شماره ----
  const la = api(adminKey, "leadAdd", { text: "علی رضایی 09121234567\n۰۹۳۵۱۱۱۲۲۳۳\nخراب\n0912 123 4567 تکراری", note: "تست" });
  ok(la.ok && la.data.added.length === 2 && la.data.dup.length === 1 && la.data.bad.length === 1, "leadAdd added/dup/bad " + JSON.stringify(la));
  ok(la.data.added[0].name === "علی رضایی" && la.data.added[1].name === "بدون نام" && la.data.added[1].phone === "09351112233", "leadAdd names+persian digits");
  ok(api(adminKey, "leadAdd", { text: "" }).ok === false && api(A.key, "leadAdd", { text: "09121230000" }).error === "FORBIDDEN" && api(nk, "leadAdd", { text: "09121230000" }).error === "FORBIDDEN", "leadAdd admin only");
  const nl = api(adminKey, "lead", { leadId: la.data.added[0].id }).data.lead; ok(nl.status === "new" && nl.phone === "09121234567", "new lead is unassigned/new");
  // ---- بازدید ----
  const vl = la.data.added.map(x => x.id);
  ok(api(adminKey, "assign", { agentCode: A.code, leadIds: vl }).ok, "assign new leads");
  ok(api(A.key, "call", { leadId: vl[0], outcome: "visit" }).error.indexOf("تاریخ") !== -1, "visit needs date");
  ok(api(A.key, "call", { leadId: vl[0], outcome: "visit", visitAt: Date.now() - 3 * 864e5 }).ok === false, "past visit rejected");
  const nsent = sent.length;
  ok(api(A.key, "call", { leadId: vl[0], outcome: "visit", visitAt: Date.now() + 3 * 864e5, note: "ساعت ۱۰" }).ok, "visit saved");
  ok(api(A.key, "call", { leadId: vl[1], outcome: "visit", visitAt: Date.now() - 3600e3 }).ok, "visit near-past ok");
  const vv = api(A.key, "lead", { leadId: vl[0] }).data; ok(vv.lead.status === "visit" && vv.lead.visitAt > Date.now() && vv.history[0].visitAt === vv.lead.visitAt, "lead shows visit date");
  const pl = api(A.key, "poll", {}).data; ok(pl.visits.length === 2 && pl.visits[0].at < pl.visits[1].at && pl.pending === api(A.key, "poll", {}).data.pending, "poll lists visits");
  ok(api(A.key, "leads", { filter: "visit" }).data.total === 2, "filter visit");
  ok(api(adminKey, "dashboard").data.totals.visit === 2, "dashboard counts visit");
  const n1 = run("visitReminders()"); ok(n1 === 1, "one reminder due, got " + n1);
  ok(run("visitReminders()") === 0, "reminder only once");
  ok(sent.slice(nsent).some(m => JSON.stringify(m).indexOf("یادآوری بازدید") !== -1), "reminder message queued");
  // ویرایش به بازدید با تاریخ جدید دوباره یادآوری می‌دهد؛ خروج از بازدید تاریخ را پاک می‌کند
  const cid = api(A.key, "lead", { leadId: vl[1] }).data.history[0].id;
  ok(api(A.key, "callEdit", { callId: cid, outcome: "visit" }).ok === false, "edit visit needs date");
  ok(api(A.key, "callEdit", { callId: cid, outcome: "deposit" }).ok && api(A.key, "lead", { leadId: vl[1] }).data.lead.visitAt === 0, "leaving visit clears date");
  ok(api(A.key, "call", { leadId: vl[0], outcome: "called" }).ok && run("visitReminders()") === 0, "later call cancels pending visit");
  // گروه‌ها در خروجی کامل
  ok(JSON.stringify(api(adminKey, "exportAll").data.sheets.Settings).indexOf("GROUPS") !== -1, "groups in exportAll");
}
console.log(`\nبک‌اند: ${pass} موفق، ${fail} ناموفق`);
process.exit(fail ? 1 : 0);
