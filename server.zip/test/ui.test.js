'use strict';
// تست رابط روی سرور واقعی: تغییر نام، ساخت گروه، نمای فقط‌خواندنیِ مدیر گروه
const fs = require('fs'), os = require('os'), path = require('path');
const { spawn, spawnSync } = require('child_process');
const { chromium } = require('playwright');
const ROOT = path.join(__dirname, '..');
const tmp = fs.mkdtempSync(path.join(os.tmpdir(), 'panel-ui-'));
const KEY = 'AAAA-BBBB-CCCC', PORT = 3925, URL = 'http://127.0.0.1:' + PORT;
let pass = 0, failn = 0;
const ok = (c, m) => { if (c) pass++; else { failn++; console.log('FAIL:', m); } };
const sleep = ms => new Promise(r => setTimeout(r, ms));
const api = (tok, action, payload) => fetch(URL + '/api', { method: 'POST', headers: { 'Content-Type': 'text/plain' }, body: JSON.stringify({ api: true, token: tok, action, payload: payload || {} }) }).then(r => r.json());

(async () => {
  fs.writeFileSync(path.join(tmp, 'd.json'), JSON.stringify({ sheets: {}, props: { ADMIN_APP_KEY: KEY } }));
  const env = { ...process.env, DB_PATH: path.join(tmp, 'p.db'), PORT: String(PORT), TELEGRAM: 'off', DAILY_REMINDER_HOUR: '' };
  spawnSync('node', ['--no-warnings', 'src/import.js', '--file', path.join(tmp, 'd.json')], { cwd: ROOT, env });
  const srv = spawn('node', ['--no-warnings', 'src/server.js'], { cwd: ROOT, env });
  for (let i = 0; i < 50; i++) { await sleep(100); try { if ((await fetch(URL + '/healthz')).ok) break; } catch (e) {} }

  // داده اولیه: دو عضو، چند شماره (از طریق منطق خود برنامه نیست؛ با ثبت مستقیم در دیتابیس ممکن نیست پس از اکشن‌ها استفاده می‌کنیم)
  const m1 = (await api(KEY, 'agentAdd', { name: 'مریم' })).data.agent;
  const m2 = (await api(KEY, 'agentAdd', { name: 'علی' })).data.agent;
  srv.kill('SIGTERM'); await sleep(600);
  // ثبت چند شماره با runtime مستقیم روی همان دیتابیس
  const { createRuntime } = require('../src/runtime.js');
  const rt = createRuntime({ dbPath: path.join(tmp, 'p.db'), files: [path.join(ROOT, 'gas/Code.gs'), path.join(ROOT, 'gas/Api.gs')], tz: 'Asia/Tehran', onOutbound() {} });
  for (let i = 1; i <= 4; i++) rt.run(`saveLead_({id: ${7000 + i}, username: "u${i}"}, {name: "مشتری ${i}", phone: "091200000${i}"})`);
  rt.flush(); rt.close();
  const srv2 = spawn('node', ['--no-warnings', 'src/server.js'], { cwd: ROOT, env });
  for (let i = 0; i < 50; i++) { await sleep(100); try { if ((await fetch(URL + '/healthz')).ok) break; } catch (e) {} }
  const free = (await api(KEY, 'leads', { filter: 'new', agent: 'none', sort: 'old', size: 50 })).data.items;
  await api(KEY, 'assign', { agentCode: m1.code, leadIds: [free[0].id, free[1].id] });
  await api(KEY, 'assign', { agentCode: m2.code, leadIds: [free[2].id] });

  const browser = await chromium.launch();
  const open = async key => {
    const ctx = await browser.newContext({ viewport: { width: 400, height: 800 }, locale: 'fa-IR' });
    await ctx.addInitScript(k => { try { localStorage.setItem('app_key', k); } catch (e) {} }, key);
    const page = await ctx.newPage();
    const errs = []; page.on('pageerror', e => errs.push(e.message));
    await page.goto(URL + '/'); await page.waitForSelector('#tabs', { timeout: 8000 });
    page.errs = errs; return page;
  };
  const txt = async (page, sel) => (await page.locator(sel).first().innerText().catch(() => '')).trim();

  // ---------- مدیر ----------
  const ad = await open(KEY);
  await ad.click('#tab-team'); await ad.waitForSelector('[data-act="agent"]');
  ok(await ad.locator('[data-act="groups"]').count() === 1, 'admin sees groups button');
  // تغییر نام
  await ad.locator('[data-act="agent"]').first().click(); await ad.waitForSelector('[data-act="agentRename"]');
  await ad.click('[data-act="agentRename"]'); await ad.fill('#rnName', 'مریم جان'); await ad.click('[data-act="agentRenameGo"]');
  await ad.waitForFunction(() => document.body.innerText.includes('مریم جان'));
  ok(true, 'rename visible in sheet');
  ok(!!(await txt(ad, '.sheet h3')).includes('مریم جان'), 'sheet title renamed');
  await ad.keyboard.press('Escape'); await ad.evaluate(() => document.querySelector('#sheet').click());
  await ad.waitForFunction(() => document.querySelector('#sheet').hidden);
  ok((await ad.locator('#list').innerText()).includes('مریم جان'), 'team list shows new name');
  // ساخت گروه
  await ad.click('[data-act="groups"]'); await ad.waitForSelector('[data-act="groupNew"]');
  await ad.click('[data-act="groupNew"]'); await ad.fill('#gName', 'دسته A'); await ad.fill('#gMgr', 'رضا'); await ad.click('[data-act="groupSaveGo"]');
  await ad.waitForSelector('.keybox code');
  const SD = process.env.SHOT_DIR; const shot = async (pg, n) => { if (SD) await pg.screenshot({ path: path.join(SD, n + '.png') }); };
  await shot(ad, 'admin_group_sheet');
  const mgrKey = (await txt(ad, '.keybox code'));
  ok(/^[A-Z2-9]{4}-[A-Z2-9]{4}-[A-Z2-9]{4}$/.test(mgrKey), 'manager key shown ' + mgrKey);
  await ad.evaluate(() => document.querySelector('#sheet').click());
  // گروه‌بندی عضو
  await ad.locator('[data-act="agent"]').first().click(); await ad.waitForSelector('[data-act="agentGroup"]');
  await ad.click('[data-act="agentGroup"]'); await ad.waitForSelector('[data-act="agentGroupGo"]');
  await ad.locator('[data-act="agentGroupGo"]').first().click();
  await ad.waitForFunction(() => document.querySelector('.sheet h3') && document.querySelector('.sheet h3').innerText.includes('دسته A'));
  ok(true, 'agent grouped (chip in sheet)');
  await ad.evaluate(() => document.querySelector('#sheet').click());
  ok((await ad.locator('#gchips').innerText()).includes('دسته A'), 'group filter chip in team tab');
  await shot(ad, 'admin_team');
  ok(ad.errs.length === 0, 'no page errors (admin): ' + ad.errs.join('|'));

  // ---------- مدیر گروه ----------
  const mg = await open(mgrKey);
  ok((await txt(mg, '.brand small')).includes('مدیر گروه') && (await txt(mg, '.brand small')).includes('دسته A'), 'manager header');
  ok(await mg.locator('#tabs button').count() === 4 && await mg.locator('#tab-assign').count() === 0, 'manager has 4 tabs, no assign');
  await mg.waitForSelector('.tile');
  ok((await mg.locator('.tiles').first().innerText()).includes('2'), 'manager dashboard shows only group leads');
  await shot(mg, 'manager_dash');
  await mg.click('#tab-leads'); await mg.waitForSelector('.lead');
  ok(await mg.locator('.lead').count() === 2, 'manager sees 2 leads, got ' + await mg.locator('.lead').count());
  ok(!(await mg.locator('#content').innerText()).includes('بدون مسئول'), 'no unassigned chip for manager');
  await mg.locator('.lead').first().click(); await mg.waitForSelector('.ov-body');
  ok(await mg.locator('#saveBtn').count() === 0 && await mg.locator('.callbtn').count() === 0 && await mg.locator('[data-act="assignOne"]').count() === 0, 'lead view is read-only');
  ok((await mg.locator('.ov-body').innerText()).includes('مسئول'), 'manager sees responsible agent');
  await shot(mg, 'manager_lead');
  await mg.click('[data-act="closeOv"]');
  await mg.click('#tab-team'); await mg.waitForSelector('[data-act="agent"]');
  ok(await mg.locator('[data-act="agent"]').count() === 1 && await mg.locator('[data-act="agentAdd"]').count() === 0 && await mg.locator('[data-act="groups"]').count() === 0, 'manager team: 1 member, no add/group buttons');
  await mg.locator('[data-act="agent"]').first().click(); await mg.waitForSelector('.sheet');
  const sh = await mg.locator('.sheet').innerText();
  ok(!sh.includes('کلید ورود') && !sh.includes('حذف') && !sh.includes('تغییر نام') && !sh.includes('CSV'), 'manager agent sheet read-only');
  ok(mg.errs.length === 0, 'no page errors (manager): ' + mg.errs.join('|'));

  // ---------- افزودن شماره (مدیر) و بازدید (عضو) ----------
  await ad.click('#tab-assign'); await ad.waitForSelector('#addtext', { state: 'attached' });
  await ad.locator('details.panel summary', { hasText: 'افزودن شماره' }).click();
  await ad.fill('#addtext', 'رضا احمدی 09125550001\n09125550002');
  await ad.click('[data-act="leadAdd"]'); await sleep(700);
  ok((await ad.locator('.toast, #toast').first().innerText().catch(() => '')).includes('2 شماره اضافه شد'), 'ui: manual add toast');
  const ag = await open(m1.key);
  await ag.locator('.lead').first().click(); await ag.waitForSelector('#outs');
  ok(await ag.locator('[data-act="pick"][data-v="visit"]').count() === 1, 'ui: visit outcome offered');
  ok(await ag.locator('#vbox').isHidden(), 'ui: visit picker hidden by default');
  await ag.click('[data-act="pick"][data-v="visit"]');
  ok(await ag.locator('#vat').isVisible() && (await ag.inputValue('#vat')).length === 16, 'ui: visit picker shown with default');
  await ag.click('#saveBtn'); await sleep(800);
  const vis = (await api(m1.key, 'poll', {})).data.visits;
  ok(vis.length === 1 && vis[0].at > Date.now(), 'ui: visit saved with date');
  ok(ag.errs.length === 0, 'no page errors (agent visit): ' + ag.errs.join('|'));

  await browser.close(); srv2.kill('SIGKILL');
  console.log(`رابط: ${pass} موفق، ${failn} ناموفق`); process.exit(failn ? 1 : 0);
})().catch(e => { console.error(e); process.exit(1); });
