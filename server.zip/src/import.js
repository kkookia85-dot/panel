'use strict';
// انتقال داده از سیستم قدیمی (Google Sheets) به سرور جدید
//   node src/import.js --url "https://script.google.com/macros/s/XXX/exec" --key "کلید-مدیر"
//   node src/import.js --file backup.json
const fs = require('fs');
const path = require('path');
const { createRuntime } = require('./runtime.js');
const ROOT = path.join(__dirname, '..');

function arg(n) { const i = process.argv.indexOf('--' + n); return i > 0 ? process.argv[i + 1] : null; }
function loadEnv(file) {
  try { fs.readFileSync(file, 'utf8').split(/\r?\n/).forEach(l => { const m = l.match(/^\s*([A-Z0-9_]+)\s*=\s*(.*?)\s*$/); if (m && !(m[1] in process.env)) process.env[m[1]] = m[2].replace(/^["']|["']$/g, ''); }); } catch (e) {}
}
loadEnv(path.join(ROOT, '.env'));

const ISO = /^\d{4}-\d\d-\d\dT\d\d:\d\d:\d\d(\.\d+)?Z$/;
const revive = v => (typeof v === 'string' && ISO.test(v)) ? new Date(v) : v;

(async () => {
  let dump;
  if (arg('file')) dump = JSON.parse(fs.readFileSync(arg('file'), 'utf8'));
  else if (arg('url') && arg('key')) {
    const r = await fetch(arg('url'), { method: 'POST', headers: { 'Content-Type': 'text/plain;charset=utf-8' }, body: JSON.stringify({ api: true, token: arg('key'), action: 'exportAll', payload: {} }), redirect: 'follow' });
    const txt = await r.text();
    let j; try { j = JSON.parse(txt); } catch (e) { throw new Error('پاسخ نامعتبر از سیستم قدیمی: ' + txt.slice(0, 200)); }
    if (!j.ok) throw new Error('سیستم قدیمی خطا داد: ' + j.error + (j.error === 'UNKNOWN_ACTION' ? ' (نسخهٔ جدید Code.gs/Api.gs را در Apps Script قرار نداده‌اید یا دوباره Deploy نکرده‌اید)' : ''));
    dump = j.data;
    const bk = path.join(ROOT, 'data', 'import-' + Date.now() + '.json');
    fs.mkdirSync(path.dirname(bk), { recursive: true });
    fs.writeFileSync(bk, JSON.stringify(dump)); fs.chmodSync(bk, 0o600);
    console.log('نسخهٔ خام داده ذخیره شد:', bk);
  } else { console.log('استفاده: node src/import.js --url <exec-url> --key <admin-key>   یا   --file backup.json'); process.exit(1); }

  const dbPath = process.env.DB_PATH || path.join(ROOT, 'data', 'panel.db');
  fs.mkdirSync(path.dirname(dbPath), { recursive: true });
  const rt = createRuntime({ dbPath, files: [path.join(ROOT, 'gas', 'Code.gs'), path.join(ROOT, 'gas', 'Api.gs')], tz: process.env.TZ_NAME || 'Asia/Tehran', onOutbound: () => {} });
  rt.call('setupProject');
  const leadsNow = rt.ss.getSheetByName('Leads');
  if (leadsNow.getLastRow() > 1 && process.argv.indexOf('--force') < 0) {
    console.log('دیتابیس جدید خالی نیست. اگر مطمئنید با --force دوباره اجرا کنید (داده‌های فعلی جایگزین می‌شود).'); process.exit(1);
  }
  const counts = {};
  Object.keys(dump.sheets).forEach(name => {
    const rows = (dump.sheets[name] || []).map(r => r.map(revive));
    if (!rows.length) return;
    const sh = rt.ss.getSheetByName(name) || rt.ss.insertSheet(name);
    const raw = rt.store.sheets.find(x => x.name === name);
    if (raw) { raw.data = []; raw.dirty.clear(); raw.truncFrom = 0; } // پاک‌سازی کامل (ردیف‌های اضافهٔ پیش‌فرض نماند)
    const w = Math.max.apply(null, rows.map(r => r.length));
    rows.forEach(r => { while (r.length < w) r.push(''); });
    sh.getRange(1, 1, rows.length, w).setValues(rows);
    counts[name] = rows.length - 1;
  });
  Object.keys(dump.props || {}).forEach(k => rt.store.setProp(k, dump.props[k]));
  rt.call('setupProject'); // مهاجرت نتایج قدیمی و ستون‌های جدید
  rt.flush(); rt.close();
  console.log('انتقال کامل شد:', JSON.stringify(counts));
})().catch(e => { console.error('خطا:', e.message); process.exit(1); });
