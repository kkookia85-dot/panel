'use strict';
// نسخهٔ پشتیبان روزانه: node src/backup.js   (توسط cron/systemd timer اجرا می‌شود)
const fs = require('fs');
const path = require('path');
const { DatabaseSync } = require('node:sqlite');
const ROOT = path.join(__dirname, '..');
const dbPath = process.env.DB_PATH || path.join(ROOT, 'data', 'panel.db');
const dir = process.env.BACKUP_DIR || path.join(ROOT, 'backups');
const keep = Number(process.env.BACKUP_KEEP || 14);
fs.mkdirSync(dir, { recursive: true });
const d = new Date().toISOString().slice(0, 10);
const out = path.join(dir, 'panel-' + d + '.db');
try { fs.unlinkSync(out); } catch (e) {}
const db = new DatabaseSync(dbPath);
db.exec(`VACUUM INTO '${out.replace(/'/g, "''")}'`);
db.close();
fs.chmodSync(out, 0o600);
fs.readdirSync(dir).filter(f => /^panel-\d{4}-\d\d-\d\d\.db$/.test(f)).sort().slice(0, -keep).forEach(f => fs.unlinkSync(path.join(dir, f)));
console.log('backup ok:', out);
