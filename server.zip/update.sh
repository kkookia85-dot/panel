#!/bin/bash
# آپدیت برنامه:  bash /opt/panel/update.sh
set -e
URL="${1:-https://github.com/kkookia85-dot/panel/raw/main/server.zip}"
cd /opt/panel
echo "دانلود نسخهٔ جدید..."
wget -qO /tmp/server.zip "$URL"
unzip -tq /tmp/server.zip >/dev/null
echo "بکاپ از دیتابیس..."
sudo -u panel node --no-warnings src/backup.js
systemctl stop panel
unzip -qo /tmp/server.zip -d /opt/panel -x ".env" "data/*" "backups/*"
chown -R panel:panel /opt/panel
systemctl start panel
sleep 3
echo "سلامت: $(curl -s http://127.0.0.1:3000/healthz) / وضعیت: $(systemctl is-active panel)"
